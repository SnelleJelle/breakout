import core.Ball;
import core.Paddle;
import core.Player;
import org.junit.Assert;
import org.junit.Test;

import java.awt.*;

public class PaddleTest {

    @Test
    public void testGetBounds() throws Exception {
        //region setup
        Player player = new Player(new Color(255, 0, 0, 100), false);
        Paddle paddle = new Paddle(player, 650);
        player.setPaddle(paddle);
        Ball ball = new Ball(player);
        player.setBall(ball);
        //endregion

        Rectangle r = new Rectangle(paddle.getxPosition(), paddle.getTopY(), paddle.getWidth(), paddle.getBottomY() - paddle.getTopY());
        Assert.assertEquals(paddle.getBounds(), r);

    }

    @Test
    public void testGetTopY() throws Exception {

        int y = 650;

        //region setup
        Player player = new Player(new Color(255, 0, 0, 100), false);
        Paddle paddle = new Paddle(player, y);
        player.setPaddle(paddle);
        Ball ball = new Ball(player);
        player.setBall(ball);
        //endregion

        Assert.assertEquals(paddle.getTopY(), y);

    }

    @Test
    public void testGetBottomY() throws Exception {
        int y = 650;
        int paddleHeight = 20;

        //region setup
        Player player = new Player(new Color(255, 0, 0, 100), false);
        Paddle paddle = new Paddle(player, y);
        player.setPaddle(paddle);
        Ball ball = new Ball(player);
        player.setBall(ball);
        //endregion

        Assert.assertEquals(paddle.getBottomY(), y + paddleHeight);

    }

    @Test
    public void testGetAndSetXPosition() throws Exception {
        //region setup
        Player player = new Player(new Color(255, 0, 0, 100), false);
        Paddle paddle = new Paddle(player, 650);
        player.setPaddle(paddle);
        Ball ball = new Ball(player);
        player.setBall(ball);
        //endregion

        int x = (1280 - paddle.getWidth()) / 2;
        paddle.setXPosition();

        Assert.assertEquals(paddle.getxPosition(), x);
    }

    @Test
    public void testGetAndSetWidth() throws Exception {
        //region setup
        Player player = new Player(new Color(255, 0, 0, 100), false);
        Paddle paddle = new Paddle(player, 650);
        player.setPaddle(paddle);
        Ball ball = new Ball(player);
        player.setBall(ball);
        //endregion

        int width = 90;
        paddle.setWidth(width);
        Assert.assertEquals(paddle.getWidth(), width);
    }

    @Test
    public void testGetSections() throws Exception {
        //region setup
        Player player = new Player(new Color(255, 0, 0, 100), false);
        Paddle paddle = new Paddle(player, 650);
        player.setPaddle(paddle);
        Ball ball = new Ball(player);
        player.setBall(ball);
        //endregion

        int width = 90;
        int sections[] = new int[7];
        int sectionWidth = width / 7;
        for (int i = 1; i <= 6; i++) {
            sections[i] = sectionWidth * i;
        }

        Assert.assertArrayEquals(paddle.getSections(), sections);
    }
}