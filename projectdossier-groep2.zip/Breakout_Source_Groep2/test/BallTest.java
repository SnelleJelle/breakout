import core.Ball;
import core.Paddle;
import core.Player;
import org.junit.Assert;
import org.junit.Test;

import java.awt.*;

//tests are outdated
//none of them makes any sense

public class BallTest {

    @Test
    public void testResetPosition() throws Exception {
        //region setup
        Player player = new Player(new Color(255, 0, 0, 100), false);
        Paddle paddle = new Paddle(player, 650);
        player.setPaddle(paddle);
        Ball ball = new Ball(player);
        player.setBall(ball);
        //endregion

        Rectangle r1 = ball.getBounds();
        ball.resetPosition();
        Rectangle r2 = ball.getBounds();

        Assert.assertNotEquals(r1, r2);
    }

    @Test
    public void testGetBounds() throws Exception {
        //region setup
        Player player = new Player(new Color(255, 0, 0, 100), false);
        Paddle paddle = new Paddle(player, 650);
        player.setPaddle(paddle);
        Ball ball = new Ball(player);
        player.setBall(ball);
        //endregion

        Rectangle r = new Rectangle(595, 650, 90, 20);
        Assert.assertEquals(paddle.getBounds(), r);
    }
}