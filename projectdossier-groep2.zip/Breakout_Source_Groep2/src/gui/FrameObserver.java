package gui;

public interface FrameObserver {
    public void update();
}
