package core;

import java.awt.*;

public interface Sprite {
    void Paint(Graphics2D g);
}
