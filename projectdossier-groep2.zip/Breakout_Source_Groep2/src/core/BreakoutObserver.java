package core;

public interface BreakoutObserver {
    void update();
}
